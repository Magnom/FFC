﻿using FF.DataModel;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace salaC_Crawler
{
    public class HPSCrawler : BaseCrawler
    {

        public enum HpsFields
        {
            link,
            size,
            quality,
            format,
            languaje
        }

        public FILMS CurrentFilm { get; set; }
        public CRAWL_URLS CurrentCrawl { get; set; }
        public string TmpFolder { get; set; }

        public string downloadURL { get; set; }
        const string FileTypeID = "19";
        const string FilePrefix = "MT_";

        public HPSCrawler()
        {
            var fType = CRAWL_FILETYPES.getById(Int32.Parse(FileTypeID)).FirstOrDefault();
            downloadURL = fType.UrlDownload;
        }

        public override List<string> ParseSearch(string strSearch)
        {
            return null;
        }


        public string Download(string pUrl, string postData)
        {


            return DownloadManager.DownloadWithPost(FilePrefix + CurrentFilm.ID.ToString() + "_o", pUrl, postData);

        }
        private List<string> ParseSearchResult(string filePath, FF.DataModel.FILMS f, int maxResultPages)
        {
            return null;

        }

        public void GetEdkLink(FILM_LINKS f)
        {
            //javascript:Download(17453,'01');
            var url = String.Format(downloadURL, f.FileLink.Split(',')[0].Replace("javascript:Download(", ""));
            var file = DownloadManager.Download("D_" + CurrentFilm.ID.ToString() + f.FileLink.Split(',')[0].Replace("javascript:Download(", ""), url);
            HtmlDocument doc = new HtmlDocument();
            doc.Load(file, Encoding.Default);
            var edk = doc.GetElementbyId("ELINKSLIST").InnerText;
            f.edkLink = edk.Replace("\n", "");
            f.Update();


        }

        public override void Parse(FF.DataModel.CRAWL_URLS cr)
        {
            HtmlDocument doc = new HtmlDocument();
            doc.Load(cr.torrentPath, Encoding.Default);

            var fLink = doc.DocumentNode.SelectNodes(string.Format("//table[contains(@class,'{0}')]", "T1"));

            foreach (var tbl in fLink)
            {


                var quality = string.Empty;
                var format = string.Empty;
                var languaje = string.Empty;
                List<hpsLink> links = new List<hpsLink>();

                foreach (var t in tbl.ChildNodes)
                {

                    var tds = t.SelectNodes(".//td");
                    if (tds != null)
                    {
                        foreach (var q in tds)
                        {
                            if (q.InnerHtml.Contains("Formato:")) { format = q.InnerText.Replace("Formato:", ""); continue; }
                            if (q.InnerHtml.Contains("Idioma:")) { languaje = getLanguajes(q); continue; }
                            if (q.InnerHtml.Contains("a href=\"javascript:Download")) { links.Add(new hpsLink()); links.Last<hpsLink>().lnkName = q.InnerText; links.Last<hpsLink>().dwId = getDwnId(q); continue; }
                            if (q.InnerHtml.Contains("Calidad:")) { quality = q.InnerText.Replace("Calidad:", ""); continue; }
                            if (q.InnerText.Contains("GB") || q.InnerText.Contains("MB") || q.InnerText.Contains("KB")) { if (links.Count > 0) { links.Last<hpsLink>().size = q.InnerText; } continue; }


                        }
                    }

                    if (links.Count > 0)
                    {

                        foreach (var l in links)
                        {
                            var cInsertCol = FF.DataModel.FILM_LINKS.GetByIdFilmUrl(CurrentFilm.ID, l.lnkName);
                            var insertar = false;
                            if (cInsertCol == null)
                            {
                                insertar = true;
                            }
                            else
                            {
                                if (cInsertCol.Count == 0) { insertar = true; }
                            }
                            if (insertar && l.lnkName != "")
                            {
                                var cInsert = CurrentFilm.AddFilmLink(2, l.lnkName, l.lnkName, "");
                                cInsert.idFilm = CurrentFilm.ID;
                                cInsert.formato = format;
                                cInsert.AudioLanguage = languaje;
                                cInsert.calidad = quality;
                                cInsert.Size = l.size;
                                cInsert.FileLink = l.dwId;
                                cInsert.Update();
                            }

                        }

                        links = new List<hpsLink>();
                        quality = string.Empty;
                        format = string.Empty;
                        languaje = string.Empty;


                    }

                }
            }

            cr.parsed = "1";
            cr.Update();
            var lLink = FF.DataModel.FILM_LINKS.GetByIdFilmUrl(CurrentFilm.ID, cr.Url);
            if (lLink != null)
            {
                foreach (var lItem in lLink)
                {
                    lItem.parsed = "1";
                    lItem.Update();
                }
            }
        }


        public string getDwnId(HtmlNode q)
        {
            var lnk = q.SelectNodes(".//a");
            var result = string.Empty;
            if (lnk != null)
            {
                result = GetLink(lnk.First<HtmlNode>());
            }

            return result;

        }

        public string getLanguajes(HtmlNode node)
        {
            var result = string.Empty;
            var imgs = node.SelectNodes(".//img");
            if (imgs != null)
            {
                foreach (var i in imgs)
                {
                    result += GetAlt(i) + "|";
                }
            }

            return result;

        }
        public void ParseFilmFile(string filePath, FF.DataModel.FILMS f, FF.DataModel.CRAWL_URLS cr)
        {
        }

        public new string GetAlt(HtmlNode node)
        {
            try
            {
                var fLink = node;
                if (fLink != null)
                {
                    return fLink.Attributes.Where(p => p.Name == "alt").First().Value;
                }

                return "";
            }
            catch { return ""; }
        }

        public new string GetLink(HtmlNode node)
        {
            try
            {
                var fLink = node;
                if (fLink != null)
                {
                    return fLink.Attributes.Where(p => p.Name == "href").First().Value;
                }

                return "";
            }
            catch { return ""; }
        }

        public string GetLink(HtmlDocument doc, string xPath)
        {
            try
            {
                var fLink = doc.DocumentNode.SelectNodes(xPath);
                if (fLink != null)
                {
                    return fLink.First().Attributes.Where(p => p.Name == "href").First().Value;
                }

                return "";
            }
            catch { return ""; }
        }

        public FF.DataModel.CRAWL_URLS GetCrawlFromUrl(string url)
        {
            return FF.DataModel.CRAWL_URLS.getByIdFilm(CurrentFilm.ID, FileTypeID).Where(p => p.Url == url).FirstOrDefault();
        }

    }
}
