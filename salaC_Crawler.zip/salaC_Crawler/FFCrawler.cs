﻿using FF.DataModel;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace salaC_Crawler
{
    public class FFCrawler:BaseCrawler
    {
        public FILMS CurrentFilm { get; set; }
        public CRAWL_URLS CurrentCrawl { get; set; }
        public string TmpFolder { get; set; }

        const string UrlBase = "http://www.filmaffinity.com";

        public override List<string> ParseSearch(string strSearch)
        {

                //strSearch = string.Format(strSearch, clearName(CurrentFilm.Title));
                string result = string.Empty;
                var file =string.Empty;
                CurrentCrawl = CurrentFilm.getFilmAffinityUrl();
                var txtBuscar = clearName(CurrentFilm.Title).Trim();
                if (CurrentCrawl.LastDownload == null)
                {

                    file = DownloadManager.Download(CurrentFilm.ID.ToString(), string.Format(strSearch, removeAccents(txtBuscar)));
                    if (file!="") result= ParseSearchResult(file, CurrentFilm, CurrentCrawl);
                }

                if (CurrentCrawl.Url == null)
                {
                    if (System.IO.File.Exists(TmpFolder + CurrentFilm.ID + ".htm")) System.IO.File.Delete(TmpFolder + CurrentFilm.ID + ".htm");
                    if (txtBuscar.Contains("ii"))
                    {
                        txtBuscar = txtBuscar.Replace("iii", " 3");
                        txtBuscar = txtBuscar.Replace("ii", " 2");
                        var url = string.Format(strSearch, HttpUtility.UrlEncode(txtBuscar.Trim(), Encoding.GetEncoding("ISO-8859-1")).Replace(' ', '+'));

                        DownloadManager.Download(CurrentFilm.ID.ToString(), url);

                        if (CurrentCrawl.LastDownload == null)
                        {
                           result = ParseSearchResult(file, CurrentFilm, CurrentCrawl);
                        }

                    }
                }
                if (CurrentCrawl.Url == null)
                {
                    if (System.IO.File.Exists(TmpFolder + CurrentFilm.ID + ".htm"))  System.IO.File.Delete(TmpFolder + CurrentFilm.ID + ".htm");
                    txtBuscar = txtBuscar.Replace("III", " Parte 3");
                    txtBuscar = txtBuscar.Replace("II", " Parte 2");
                    var url = string.Format(strSearch, HttpUtility.UrlEncode(txtBuscar.Trim(), Encoding.GetEncoding("ISO-8859-1")).Replace(' ', '+'));

                    DownloadManager.Download(CurrentFilm.ID.ToString(), url);

                    if (CurrentCrawl.LastDownload == null)
                    {
                        result = ParseSearchResult(file, CurrentFilm, CurrentCrawl);
                    }

                }
                if (CurrentCrawl.Url == null)
                {
                    if (System.IO.File.Exists(TmpFolder + CurrentFilm.ID + ".htm")) System.IO.File.Delete(TmpFolder + CurrentFilm.ID + ".htm");
                    txtBuscar = removeAccents(txtBuscar);

                    var url = string.Format(strSearch, HttpUtility.UrlEncode(txtBuscar.Trim(), Encoding.GetEncoding("ISO-8859-1")).Replace(' ', '+'));

                    DownloadManager.Download(CurrentFilm.ID.ToString(), url);

                    if (CurrentCrawl.LastDownload == null)
                    {
                        result = ParseSearchResult(file, CurrentFilm, CurrentCrawl);
                    }

                }
                //Parse filmaffinity file
                //guardar url i fecha en db
                return new List<string>() {result};
                //return CurrentCrawl.url;

            }
            
    

           private string ParseSearchResult(string filePath, FF.DataModel.FILMS f,FF.DataModel.CRAWL_URLS cr)
         {
            try
            {

                HtmlDocument doc = new HtmlDocument();
                doc.Load(filePath, Encoding.Default);

                //var t = doc.DocumentNode.SelectNodes(string.Format("//*[contains(@class,'{0}')]", "mc-info-container"));
                if (doc.DocumentNode.SelectNodes("//title")[0].InnerText.IndexOf("Búsqueda avanzada") == -1)
                {

                    if (doc.DocumentNode.SelectNodes("//title")[0].InnerText.IndexOf("B&uacute;squeda de &quot;") != -1)
                    {
                        var d = doc.DocumentNode.SelectNodes(string.Format("//*[contains(@class,'{0}')]", "mc-info-container"));
                        if (d != null)
                        {
                            foreach (var n in d)
                            {
                                var txt = n.InnerText;

                                if (
                                        (txt.IndexOf(f.Year) != -1 ||
                                        txt.IndexOf((Int32.Parse(f.Year) - 1).ToString()) != -1 ||
                                        txt.IndexOf((Int32.Parse(f.Year) + 1).ToString()) != -1
                                   ) && (removeAccents(txt.Replace("\r", "").Replace("\n", "")).IndexOf(removeAccents(clearName(f.GetDirectorName())), StringComparison.InvariantCultureIgnoreCase)) != -1)
                                {

                                    //var dwn = new DownLoader();
                                    //dwn.ProxyUrl = Properties.Settings.Default.URLProxy;
                                    //dwn.DestinationForder = PathFiles;

                                    //dwn.Download(f.ID.ToString(), UrlBase + n.SelectNodes("child::*")[0].FirstChild.Attributes[0].Value);
                                    cr.Url = UrlBase + n.SelectNodes("child::*")[0].FirstChild.Attributes[0].Value;
                                    //cr.LastDownload = DateTime.Now;
                                    //cr.path = PathFiles  + f.ID + ".htm";                                
                                }

                            }
                        }
                    }
                    else
                    {

                        var mainTitle = doc.DocumentNode.SelectNodes(string.Format("//*[contains(@id,'{0}')]", "main-title"))[0];

                        if (!(mainTitle.InnerText == "Búsqueda avanzada"))
                        {
                            //if (!System.IO.File.Exists(PathFiles + @"\" + f.ID + ".htm")) System.IO.File.Copy(filePath, PathFiles + @"\" + f.ID + ".htm");

                            cr.Url = UrlBase + mainTitle.FirstChild.Attributes[0].Value;
                            //cr.path = PathFiles + @"\" + f.ID + ".htm";
                            //cr.LastDownload = DateTime.Now;                    
                        }

                    }
                    return cr.Url;
                }
                else {
                    return "";
                }
                
            }
            catch (Exception e)
            {

               // throw;
                return "";
            }


        }
        public override void Parse(FF.DataModel.CRAWL_URLS cr)
        {
            try
            {
                var filePath = DownloadManager.Download(CurrentFilm.ID.ToString(), cr.Url);
                
                HtmlDocument doc = new HtmlDocument();
                doc.Load(filePath, Encoding.Default);

                FF.DataModel.FILMS.Campos currentField = FF.DataModel.FILMS.Campos.tituloOriginal;
                bool procesField = false;

                var d = doc.DocumentNode.SelectNodes(string.Format("//*[contains(@class,'{0}')]", "movie-info"));
                if (d != null)
                {
                    foreach (var q in d)
                    {
                        foreach (var n in q.ChildNodes)
                        {


                            if (n.InnerText == "T&iacute;tulo original") { currentField = FF.DataModel.FILMS.Campos.tituloOriginal; procesField = true; continue; }
                            if (n.InnerText == "M&uacute;sica") { currentField = FF.DataModel.FILMS.Campos.musica; procesField = true; continue; }
                            if (n.InnerText == "Fotograf&iacute;a") { currentField = FF.DataModel.FILMS.Campos.fotografia; procesField = true; continue; }
                            if (n.InnerText == "Productora") { currentField = FF.DataModel.FILMS.Campos.productora; procesField = true; continue; }
                            if (n.InnerText == "G&eacute;nero") { currentField = FF.DataModel.FILMS.Campos.genero; procesField = true; continue; }
                            if (n.InnerText == "Premios") { currentField = FF.DataModel.FILMS.Campos.premios; procesField = true; continue; }

                            if (n.InnerText == "Director") { currentField = FF.DataModel.FILMS.Campos.director; procesField = true; continue; }

                            if (n.InnerText == "Gui&oacute;n") { currentField = FF.DataModel.FILMS.Campos.guion; procesField = true; continue; }
                            if (n.InnerText == "Duraci&oacute;n") { currentField = FF.DataModel.FILMS.Campos.duracion; procesField = true; continue; }


                            if (procesField && n.InnerText.Trim() != "")
                            {
                                var valorInsertar = n.InnerText;
                                if (currentField == FF.DataModel.FILMS.Campos.duracion)
                                {
                                    if (CurrentFilm.Duration == 0)
                                    {
                                        valorInsertar = valorInsertar.Replace("&nbsp;min.", "").Trim();
                                        CurrentFilm.SetFieldValue(currentField, valorInsertar, n.InnerHtml);
                                    }
                                }
                                else
                                {
                                    CurrentFilm.SetFieldValue(currentField, valorInsertar, n.InnerHtml);
                                }
                                procesField = false;
                            }

                        }
                    }
                }

                var r = doc.DocumentNode.SelectNodes(string.Format("//*[contains(@itemprop,'{0}')]", "ratingValue"));
                if (r != null)
                {
                    CurrentFilm.Ratting = Double.Parse(r[0].InnerText);
                }


                var nCaratula = doc.DocumentNode.SelectNodes(string.Format("//*[contains(@id,'{0}')]", "movie-main-image-container"));
                if (nCaratula != null)
                {
                    //f.UrlImagen = nCaratula[0].FirstChild.NextSibling.Attributes[1].Value;
                    var urlCaratula = nCaratula[0].FirstChild.NextSibling.Attributes.Where(p => p.Name == "href").FirstOrDefault();
                    if (urlCaratula != null) CurrentFilm.UrlImagen = urlCaratula.Value;
                    else
                    {
                        urlCaratula = nCaratula[0].FirstChild.NextSibling.Attributes.Where(p => p.Name == "src").FirstOrDefault();
                        if (urlCaratula != null) CurrentFilm.UrlImagen = urlCaratula.Value;
                    }

                    if (CurrentFilm.UrlImagen != "")
                    {
                        WebClient webclient = new WebClient();
                        using (Stream stream = webclient.OpenRead(CurrentFilm.UrlImagen))
                        {
                            byte[] array;
                            using (var ms = new MemoryStream())
                            {
                                stream.CopyTo(ms);
                                array = ms.ToArray();
                            }

                            var cov = CurrentFilm.getCover();
                            cov.Imagen = array;
                            cov.Update();
                        }

                    }

                }

                var tabs = doc.DocumentNode.SelectNodes(string.Format("//*[@class='{0}']", "ntabs"));
                if (tabs != null)
                {
                    foreach (var tab in tabs[0].ChildNodes)
                    {
                        if (tab.InnerText.Contains("Trailers"))
                        {
                            var crImageUrl = CurrentFilm.getFilmAffinityVideoUrl();
                            crImageUrl.Url = UrlBase + tab.FirstChild.Attributes[0].Value;
                            crImageUrl.NumberItems = (int?)Int32.Parse(tab.InnerText.Replace("Trailers", "").Replace("&nbsp;", "").Replace("[", "").Replace("]", ""));
                            crImageUrl.Update();
                        }

                        if (tab.InnerText.Contains("Im&aacute;genes"))
                        {
                            var crVideoUrl = CurrentFilm.getFilmAffinityImageUrl();
                            crVideoUrl.Url = UrlBase + tab.FirstChild.Attributes[0].Value;
                            crVideoUrl.NumberItems = (int?)Int32.Parse(tab.InnerText.Replace("Im&aacute;genes", "").Replace("&nbsp;", "").Replace("[", "").Replace("]", ""));
                            crVideoUrl.Update();
                        }

                    }
                }


                CurrentFilm.Update();
                cr.Update();
                cr.LastRead = DateTime.Now;

            }
            catch (Exception e)
            {

                throw;
            }
        }
    }
}
