﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace salaC_Crawler
{
    public interface ICrawler
    {
       // public void ParseSearchFile(string filePath, FF.DataModel.CRAWL_URLS cr);
        void Parse(FF.DataModel.CRAWL_URLS cr);
        List<string> ParseSearch(string strSearch);
    }
}
