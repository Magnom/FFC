﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web;

namespace salaC_Crawler
{
    public class NSCCrawler : BaseCrawler
    {
        private static int getIdFromUrl(string UrlParse)
        {
            return Int32.Parse(UrlParse.Split('?')[1].Split('=')[1]);
        }


        public override List<string> ParseSearch(string strSearch)
        {
            string filePath = string.Empty;
            List<string> result = new List<string>();
            string tmpFilename = Guid.NewGuid() + ".htm";


            filePath = DownloadManager.Download(tmpFilename, UrlParse + HttpUtility.UrlEncode(strSearch, System.Text.Encoding.GetEncoding("ISO-8859-1")), false);

            HtmlDocument doc = new HtmlDocument();
            doc.Load(filePath, Encoding.Default);

            var t = doc.DocumentNode.SelectNodes(string.Format("//*[contains(text(),'{0}')]", "Se han encontrado las siguientes películas"));
            if (t != null)
            {

                var d = t[0].SelectNodes(string.Format("..//a[contains(@href,'{0}')]", @"pelicula.php?p="));
                if (d != null)
                {
                    foreach (var n in d)
                    {

                        if (n.InnerText.IndexOf(strSearch, StringComparison.InvariantCultureIgnoreCase) != -1)
                        {
                            var link = GetLink(n);
                            result.Add(link);
                        }

                    }
                }
            }
            System.IO.File.Delete(tmpFilename);
            return result;


        }

        public override void Parse(FF.DataModel.CRAWL_URLS cr)
        {
            try
            {
                string filePath = string.Empty;
                int idMigrated = getIdFromUrl(UrlParse);

                if (FF.DataModel.FILMS.getByIdMigrated(idMigrated) == null)
                {
                    //dwn.DownloadRange(Properties.Settings.Default.PathFiles, "http://www.nosolocine.es/pelicula.php?p=", Properties.Settings.Default.IdInicial, Properties.Settings.Default.IdFinal);
                    filePath = DownloadManager.Download(idMigrated + ".htm", UrlParse, false);
                    var f = FF.DataModel.FILMS.getByIdMigrated(idMigrated);
                    if (f == null) f = new FF.DataModel.FILMS();

                    HtmlDocument doc = new HtmlDocument();
                    doc.Load(filePath, Encoding.Default);
                    var t = doc.DocumentNode.SelectNodes(string.Format("//*[contains(@class,'{0}')]", "titulocontenido"));
                    f.Title = t[0].InnerText.Replace(" - Ficha de la película", "").Replace("\t", "").Replace("\n", "");
                    f.IdMigrated = idMigrated;
                    var d = doc.DocumentNode.SelectNodes(string.Format("//*[contains(@class,'{0}')]", "datoscontenido"));
                    var tipo = string.Empty;
                    var valor = string.Empty;

                    foreach (var n in d[1].SelectNodes("//p"))
                    {
                        var parsed = false;

                        if (n.InnerHtml == "")
                        {
                            f.Year = n.NextSibling.NextSibling.InnerText.Replace(":", "").Replace("\t", "").Replace(" ", "");
                            parsed = true;
                        }

                        if (n.InnerHtml.Contains("País:") || n.InnerHtml.Contains("<span class=\"Estilo4\">País</span>:"))
                        {
                            foreach (var pais in Regex.Split(n.InnerHtml.Replace("<span class=\"Estilo4\">País</span>: ", ""), ","))
                            {
                                //f.getCountries().Add(ParsePais(pais, f.ID));
                                f.AddCountry(ParsePais(pais, f.ID));
                            }
                            // f.idCountry = n.InnerText;
                            //   parsed = true;
                        }
                        if (n.InnerHtml.Contains("Distribuidora:"))
                        {
                            f.Distribuidora = n.InnerHtml.Replace("<span class=\"Estilo4\">Distribuidora:</span>", "");
                            parsed = true;
                        }
                        if (n.InnerHtml.Contains("Duración:"))
                        {
                            try
                            {
                                f.Duration = Int32.Parse(n.InnerText.Replace("Duración:", "").Replace(" minutos", ""));
                            }
                            catch { }
                            parsed = true;
                        }
                        if (n.InnerHtml.Contains("Clasificación:"))
                        {
                            f.Clasification = n.InnerHtml.Replace("<span class=\"Estilo4\">Clasificación:</span>", "");
                            parsed = true;
                        }
                        if (n.InnerHtml.Contains("Género:"))
                        {
                            f.Genero = n.InnerHtml.Replace("<span class=\"Estilo4\">Género: </span>", "");

                            parsed = true;
                        }

                        //GUARDAR EL FILM
                        if (f.ID == 0) FF.DataModel.FILMS.AddFilm(f);

                        if (n.InnerHtml.Contains("Dirección:"))
                        {
                            foreach (var pers in Regex.Split(n.InnerHtml, "<a href=\"/persona.php"))
                            {
                                ParsePerson(pers, 1, f.ID);
                            }
                            parsed = true;
                        }

                        if (n.InnerHtml.Contains("Guión:"))
                        {
                            foreach (var pers in Regex.Split(n.InnerHtml, "<a href=\"/persona.php"))
                            {
                                ParsePerson(pers, 2, f.ID);
                            }

                            parsed = true;
                        }

                        if (n.InnerHtml.Contains("Intérpretes:"))
                        {
                            foreach (var pers in Regex.Split(n.InnerHtml, "<a href=\"/persona.php"))
                            {
                                ParsePerson(pers, 3, f.ID);
                            }
                            parsed = true;
                        }

                        if (!parsed) f.Description = n.InnerText;

                    }

                    f.Create_Id = "SYS";
                    f.Create_Dt = DateTime.Now;
                    f.Update();
                }
            }
            catch (DbEntityValidationException e)
            {
                foreach (var eve in e.EntityValidationErrors)
                {
                    Console.WriteLine("Entity of type \"{0}\" in state \"{1}\" has the following validation errors:",
                        eve.Entry.Entity.GetType().Name, eve.Entry.State);
                    foreach (var ve in eve.ValidationErrors)
                    {
                        Console.WriteLine("- Property: \"{0}\", Error: \"{1}\"",
                            ve.PropertyName, ve.ErrorMessage);
                    }
                }
                throw;
            }
        }

        public FF.DataModel.COUNTRIES ParsePais(string textPase, int idFilm)
        {
            try
            {
                var p = FF.DataModel.COUNTRIES.getByIdMigrated(textPase);
                if (p == null)
                {
                    p = new FF.DataModel.COUNTRIES();
                    p.Description = textPase;
                    FF.DataModel.COUNTRIES.AddCountry(p);

                }

                return p;
            }

            catch
            {
                return null;
            }

        }

        public void ParsePerson(string textPase, int idRol, int idFilm)
        {
            try
            {
                string aux = textPase.Substring(textPase.IndexOf("?"), textPase.Length - textPase.IndexOf("?"));
                var c = aux.Split('=')[1].Replace("\"", "").Replace("</a", "").Split('>');
                string name = string.Empty;
                string papel = string.Empty;
                if (c[1].IndexOf("(") != -1)
                {
                    papel = c[1].Substring(c[1].IndexOf("("), c[1].IndexOf(")") - c[1].IndexOf("(") + 1);
                    name = c[1].Replace(papel, "");
                }
                else
                {
                    name = c[1];
                }
                var p = FF.DataModel.PERSON.GetByIdMigrated(Int32.Parse(c[0]));
                if (p == null)
                {
                    p = new FF.DataModel.PERSON();
                    p.IdMigrado = Int32.Parse(c[0]);
                    p.Name = name;
                    p.Create_Id = "SYS";
                    p.Create_Dt = DateTime.Now;
                    FF.DataModel.PERSON.AddPerson(p);

                }

                var fp = FF.DataModel.FILMS_PERSONS.getByIdMigrated(p.ID, idFilm, idRol);
                if (fp == null)
                {
                    fp = new FF.DataModel.FILMS_PERSONS();
                    fp.IdPerson = p.ID;
                    fp.IdRole = idRol;
                    fp.IdFilm = idFilm;
                    fp.Personaje = papel;
                    p.Create_Id = "SYS";
                    p.Create_Dt = DateTime.Now;
                    FF.DataModel.FILMS_PERSONS.AddPerson(fp);

                }
            }
            catch { }

        }
    }
}
