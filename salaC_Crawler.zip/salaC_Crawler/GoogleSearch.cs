﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace salaC_Crawler
{
    public class GoogleSearch
    {
        public string ApiKey { get; set; }
        public string ApiContext { get; set; }
        
        public GoogleApiResult Results { get; set; }
        public string strUrl { get; set; }

        //private readonly string strUrl = "https://www.googleapis.com/customsearch/v1?q={0}&cx={2}&exactTerms={0}&key={1}";
        
        public void Search(string psearch) {

            var Cliente = new WebClient();
            Cliente.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            Cliente.Headers.Add("Referer", "www.saladcine.es");
        
            var data = Cliente.DownloadData(string.Format(strUrl, psearch, ApiKey, ApiContext));


            var s = new DataContractJsonSerializer(typeof(GoogleApiResult));
            Results = (GoogleApiResult)s.ReadObject(new MemoryStream(data));
        }

        public FF.DataModel.CRAWL_URLS GetCrawlFromUrl(string url,int pId)
        {
            
            var cr = FF.DataModel.CRAWL_URLS.getByIdFilm(pId).Where(p => p.Url == url).FirstOrDefault();
            if (cr==null) {

                cr = new FF.DataModel.CRAWL_URLS();
                cr.idFilm = pId;
                cr.type = getTypeFromUrl(url);
                cr.Url = url;
                FF.DataModel.CRAWL_URLS.Add(cr);
                
            }

            return cr;

        }


        //TODO:Put in a table/sp
        public string getTypeFromUrl(string url)
        {
            if (url.Contains ("www.p2platinos.com")) return "31";
            if (url.Contains ("www.mejorenvo.com")) return "32";
            if (url.Contains ("www.emuletotal.com")) return "33";
            if (url.Contains ("www.tomadivx.org")) return "20";
            if (url.Contains ("www.divxclasico.com")) return "24";
            if (url.Contains ("wwww.sharethefiles.com")) return "23";
            if (url.Contains ("www.hispashare.com")) return "19";
            if (url.Contains ("www.elitefreak.net")) return "21";
            if (url.Contains("www.seriesyonkis.com")) return "34";
            

            return "";
        }

    }
}
