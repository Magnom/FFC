﻿using FF.DataModel;
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace salaC_Crawler
{
    public class MTCrawler : BaseCrawler
    {
        public FILMS CurrentFilm { get; set; }
        public CRAWL_URLS CurrentCrawl { get; set; }
        public string TmpFolder { get; set; }

        public string UrlBase { get; set; }
        public string PathTorrent { get; set; }
        public string UrlDownload { get; set; }

        const string FileTypeID = "5";
        const string FilePrefix = "MT_";


        public MTCrawler()
        {
            var fType = CRAWL_FILETYPES.getById(Int32.Parse(FileTypeID)).FirstOrDefault();
            UrlBase = fType.UrlBase;
            PathTorrent = fType.DownloadPath;
            UrlDownload = fType.UrlDownload;

        }

        public override List<string> ParseSearch(string strSearch)
        {

            var url = string.Format(strSearch, removeAccents(clearName(CurrentFilm.Title)).Trim().Replace(' ', '+'));
            var file = DownloadManager.Download(FilePrefix + CurrentFilm.ID.ToString(), url);
            var lsUrl = ParseSearchResult(file, CurrentFilm, 1);
            if (lsUrl == null) lsUrl = new List<string>();

            if (removeAccents(clearName(CurrentFilm.Title)) != CurrentFilm.Title)
            {
                url = string.Format(strSearch, CurrentFilm.Title.Trim().Replace(' ', '+'));
                file = DownloadManager.Download(FilePrefix + CurrentFilm.ID.ToString() + "_c", url);
                var lsUrl_o = ParseSearchResult(file, CurrentFilm, 1);
                if (lsUrl_o != null) lsUrl = lsUrl.Concat(lsUrl_o).ToList<string>();
            }

            if (lsUrl.Count == 0 && CurrentFilm.OriginalTitle != null)
            {
                url = string.Format(strSearch, CurrentFilm.OriginalTitle.Trim().Replace(' ', '+'));
                file = DownloadManager.Download(FilePrefix + CurrentFilm.ID.ToString() + "_o", url);
                lsUrl = ParseSearchResult(file, CurrentFilm, 1);
                if (lsUrl == null) lsUrl = new List<string>();
            }
            if (lsUrl.Count == 0)
            {
                url = string.Format(strSearch, clearName(CurrentFilm.Title).Trim().Replace(' ', '+') + ' ' + CurrentFilm.Year);
                file = DownloadManager.Download(FilePrefix + CurrentFilm.ID.ToString() + "_y", url);
                lsUrl = ParseSearchResult(file, CurrentFilm, 100);
                if (lsUrl == null) lsUrl = new List<string>();
                url = string.Format(strSearch, clearName(CurrentFilm.Title).Trim().Replace(' ', '+') + ' ' + CurrentFilm.GetDirectorName());
                file = DownloadManager.Download(FilePrefix + CurrentFilm.ID.ToString() + "_d", url);
                var lsUrl2 = ParseSearchResult(file, CurrentFilm, 100);
                if (lsUrl2 == null) lsUrl2 = new List<string>();
                lsUrl = lsUrl.Concat(lsUrl2).ToList<string>();
            }
            return lsUrl;
        }



        private List<string> ParseSearchResult(string filePath, FF.DataModel.FILMS f, int maxResultPages)
        {
            try
            {

                var found = 0;
                var result = new List<string>();
                HtmlDocument doc = new HtmlDocument();
                doc.Load(filePath, Encoding.Default);

                var resultsTable = doc.DocumentNode.SelectNodes(string.Format("//td[contains(text(),'{0}')]", @"Has realizado una búsqueda con"))[0].ParentNode.ParentNode;

                if (resultsTable != null)
                {
                    foreach (var node in resultsTable.SelectNodes(".//a"))
                    {
                        var url = string.Concat(UrlBase, GetLink(node));
                        if (!url.ToLower().Contains("juego-descargar-torrent"))
                        {
                            var descFile = node.InnerText;
                            found++;
                            result.Add(url);
                            f.AddLinkFile(FILMS.LinkTypes.mejorTorrent, descFile, url, null);
                        }
                    }
                }



                return result;
            }
            catch (Exception e)
            {
                return null;
            }


        }
        public override void Parse(FF.DataModel.CRAWL_URLS cr)
        {
            try
            {
                if (cr.LastDownload == null)
                {
                    var file = DownloadManager.Download(CurrentFilm.ID + "_" + cr.Url.Split('/').Last(), cr.Url);
                    cr.path = file;
                    cr.LastDownload = DateTime.Now;
                    cr.Update();
                }
                CurrentCrawl = cr;
                ParseFilmFile(cr.path, CurrentFilm, cr);
            }
            catch (Exception e)
            {
                //throw;
            }
        }

        public void ParseFilmFile(string filePath, FF.DataModel.FILMS f, FF.DataModel.CRAWL_URLS cr)
        {
            HtmlDocument doc = new HtmlDocument();
            doc.Load(filePath, Encoding.Default);

            var l = f.GetFilmLink(cr.Url);

            if (doc.DocumentNode.InnerHtml.Contains(f.GetDirectorName()) && doc.DocumentNode.InnerHtml.Contains(f.Year == null ? "" : f.Year))
            {
                l.State = 2;
            }
            else
            {
                l.State = 4;
            }


            l.Update();


            var fLink = doc.DocumentNode.SelectNodes(string.Format("//a[contains(@href,'{0}')]", ".torrent")).First();
            var lnkValue = GetLink(fLink);
            var lnkFields = Regex.Split(lnkValue, "%2F");
            var filename = string.Concat(UrlDownload, lnkFields.Last().Split('&')[0]);
            if (filename != "")
            {
                var foder = string.Format("{0}{1}", PathTorrent, f.ID);
                if (!System.IO.Directory.Exists(foder)) System.IO.Directory.CreateDirectory(foder);
                foder += "\\";
                var pathAntes = DownloadManager.DestinationForder;
                DownloadManager.DestinationForder = PathTorrent + @"\" + f.ID + @"\";
                //var file = DownloadManager.Download(f.ID + lnkFields.Last().Split('&')[0], filename, false);
                //DownloadManager.DestinationForder = pathAntes;
                cr.torrentPath = f.ID + lnkFields.Last().Split('&')[0];
                cr.Update();
                l.torrentLink = lnkValue;
                l.torrentName = lnkFields.Last().Split('&')[0];
                //ParseTorrent(PathTorrent + @"\" + f.ID + @"\" + cr.torrentPath, l);


            }

            var tamanyo = doc.DocumentNode.SelectNodes(string.Format("//b[contains(text(),'{0}')]", "Tamaño:")).First();
            if (tamanyo != null)
            {
                l.Size = tamanyo.NextSibling.InnerText;
            }

            l.Update();
        }

        public new string GetLink(HtmlNode node)
        {
            try
            {
                var fLink = node;
                if (fLink != null)
                {
                    return fLink.Attributes.Where(p => p.Name == "href").First().Value;
                }

                return "";
            }
            catch { return ""; }
        }

        public string GetLink(HtmlDocument doc, string xPath)
        {
            try
            {
                var fLink = doc.DocumentNode.SelectNodes(xPath);
                if (fLink != null)
                {
                    return fLink.First().Attributes.Where(p => p.Name == "href").First().Value;
                }

                return "";
            }
            catch { return ""; }
        }

        public FF.DataModel.CRAWL_URLS GetCrawlFromUrl(string url)
        {
            return FF.DataModel.CRAWL_URLS.getByIdFilm(CurrentFilm.ID, FileTypeID).Where(p => p.Url == url).FirstOrDefault();
        }

    }
}
