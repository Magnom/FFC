﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace salaC_Crawler
{
    public class hpsLink
    {
        public string lnkName { get; set; }
        public string size { get; set; }
        public string dwId { get; set; }
    }
}
